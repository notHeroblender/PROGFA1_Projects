# from dae_progfa_lib.progfa_engine import *
import dae_progfa_lib as pfe
from dae_progfa_lib import ShapeMode, MouseButton

# Create an instance of ProgfaEngine and set window size (width, height):
engine = pfe.ProgfaEngine(800, 600)

# Set the frame rate to x frames per second:
engine.set_fps(60)


# setup: Only executed once, at startup:
def setup():
    pass


# render: Being executed over and over, as fast as the frame rate, use to draw:
def render():
    engine.background_color = (1, 1, 1)
    pass


# evaluate: Being executed over and over, as fast as the frame rate, use to update:
def evaluate():
    pass


# mouse_pressed_event: Only executed when a mouse button was pressed!:
def mouse_pressed_event(mouse_x: int, mouse_y: int, mouse_button: MouseButton):
    pass


# key_pressed_event: Only executed when a key was pressed!:
def key_up_event(key: str):
    pass


# Engine stuff; best not to mess with this:
engine._setup = setup
engine._evaluate = evaluate
engine._render = render
engine._mouse_pressed_event = mouse_pressed_event
engine._key_up_event = key_up_event

# Start the game loop:
engine.play()
