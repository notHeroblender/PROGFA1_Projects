# file that marks the directory as a Python package
from .progfa_engine import ProgfaEngine
from .progfa_engine import ShapeMode
from .progfa_engine import MouseButton


def create_engine(width, height):
    return ProgfaEngine(width, height)
