# DAE PROGFA ENGINE

The Programming for artists engine library was created to have an easy to use environment for the programming for artists 1 course in DAE, which fully prepares for the courses that follow in the third and fourth semester of the course.

## INSTALLATION

You can install ProgfaEngine using pip:
```bash
# First, download the install files:
progfa_lib-1.0.1.tar.gz
progfa_lib-1.0.1-py3-none-any.whl
```
```bash
# REPLACE <path> with the actual location of the mentioned .tar.gz and .whl file
#   make sure the path does not contain spaces or special characters!
pip install <path>/progfa_lib-1.0.1-py3-none-any.whl
```

## USAGE
```bash
from progfa_lib.templates import template
```
```bash
from progfa_lib import *
```

## DOCUMENTATION
Coming soon...

## EXAMPLES
Coming soon...

## CHANGELOG
Changelog.md coming soon...
